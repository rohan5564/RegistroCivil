
package Interfaces;


public interface Registro_Civil {
    boolean registrar();
    boolean registrarDefuncion();
    boolean registrarMatrimonio();
}