
package Enums;


public enum Tema{
        CLARO, OSCURO, ACTUAL
}
